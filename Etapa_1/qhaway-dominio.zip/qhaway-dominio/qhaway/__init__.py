"""Paquete QHAWAY."""
