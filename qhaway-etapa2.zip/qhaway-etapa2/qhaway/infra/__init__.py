"""Infraestructura de QHAWAY (Etapa 2): persistencia SQLite + carpetas (AD-03).

Esta capa depende del dominio (importa la máquina de estados y, más adelante, el
cálculo de nota), pero el dominio NO depende de ésta: la flecha va en un solo
sentido (AD-02).
"""

from __future__ import annotations

from .ciclo import Ciclo, abrir_ciclo, crear_ciclo
from .almacen import ReporteIntegridad, Rutas
from .reconstruccion import ReporteReconstruccion, reconstruir_desde_carpetas

__all__ = [
    "Ciclo",
    "crear_ciclo",
    "abrir_ciclo",
    "Rutas",
    "ReporteIntegridad",
    "ReporteReconstruccion",
    "reconstruir_desde_carpetas",
]
